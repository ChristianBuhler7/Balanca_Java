package model;

import java.util.Date;

public class Engenheiro {

    /**
     * @return the idEngenheiro
     */
    public int getIdEngenheiro() {
        return idEngenheiro;
    }

    /**
     * @param idEngenheiro the idEngenheiro to set
     */
    public void setIdEngenheiro(int idEngenheiro) {
        this.idEngenheiro = idEngenheiro;
    }

    /**
     * @return the dsEngenheiro
     */
    public String getDsEngenheiro() {
        return dsEngenheiro;
    }

    /**
     * @param dsEngenheiro the dsEngenheiro to set
     */
    public void setDsEngenheiro(String dsEngenheiro) {
        this.dsEngenheiro = dsEngenheiro;
    }

    /**
     * @return the nrCREA
     */
    public String getNrCREA() {
        return nrCREA;
    }

    /**
     * @param nrCREA the nrCREA to set
     */
    public void setNrCREA(String nrCREA) {
        this.nrCREA = nrCREA;
    }

    /**
     * @return the dtAdmissao
     */
    public Date getDtAdmissao() {
        return dtAdmissao;
    }

    /**
     * @param dtAdmissao the dtAdmissao to set
     */
    public void setDtAdmissao(Date dtAdmissao) {
        this.dtAdmissao = dtAdmissao;
    }

    
   private int idEngenheiro;
   private String dsEngenheiro;
   private String nrCREA;
   private Date dtAdmissao;
}