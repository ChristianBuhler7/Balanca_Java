package dao;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.Fase;

public class DaoFase {
    private DataSource dataSource;

    public DaoFase(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<Fase> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM CLASSIFICACAO";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<Fase> lista = new ArrayList<>();
            while (rs.next()) {
                Fase cat = new Fase();
                cat.idFase(rs.getString("idFase"));
                cat.dsFase(rs.getString("dsFase"));
                lista.add(cat);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(JFClassificacao cat) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO CLASSIFICACAO "
                       + "(idClassificacao, dsClassificacao, qtTotal, vlTotal) "
                       + "VALUES (?, ?, ?, ?)";
 
            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, cat.getIdClassificacao());
            ps.setString(2, cat.getDsClassificacao()); 
            ps.setInt(3, cat.getQtTotal());
            ps.setDouble(4, cat.getVlTotal());

            ps.executeUpdate(); 

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }
    
   

    public void alterar(JFClassificacao cat) {
    PreparedStatement ps = null;

    try {
        String SQL = "UPDATE CLASSIFICACAO "
           + "SET dsClassificacao=?, qtTotal=?, vlTotal=? "
           + "WHERE idClassificacao=?";

        ps = dataSource.getConnection().prepareStatement(SQL);

        ps.setString(1, cat.getDsClassificacao());
        ps.setInt(2, cat.getQtTotal());
        ps.setDouble(3, cat.getVlTotal());
        ps.setString(4, cat.getIdClassificacao());

        ps.executeUpdate();

        JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null,
                "Erro ao alterar: " + ex.getMessage());
    } finally {
        dataSource.closeDataSource();
    }
}
    
     public void excluir(String codigo){
       Connection con = dataSource.getConnection();
       PreparedStatement ps = null;

       try{
           String SQL = "DELETE FROM CLASSIFICACAO WHERE (idClassificacao=?)";

      ps = con.prepareStatement(SQL);
      ps.setString(1,codigo);

           ps.executeUpdate();
           ps.close();

           JOptionPane.showMessageDialog(null,"Excluido com sucesso!");
       } catch (SQLException ex){
           JOptionPane.showMessageDialog(null,"Erro ao excluir!\n"+ex);
       }
       finally{
           dataSource.closeDataSource();
       }
   }
    
    
    public ArrayList<JFClassificacao> seleciona(String descricao) {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM CLASSIFICACAO WHERE dsClassificacao LIKE?";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1,"%"+descricao+"%");
            
            ResultSet rs = ps.executeQuery();

            ArrayList<JFClassificacao> lista = new ArrayList<>();
            while (rs.next()) {
                JFClassificacao cat = new JFClassificacao();
                cat.setIdClassificacao(rs.getString("idClassificacao"));
                cat.setDsClassificacao(rs.getString("dsClassificacao"));
                cat.setQtTotal(rs.getInt("qtTotal"));
                cat.setVlTotal(rs.getDouble("vlTotal"));
                lista.add(cat);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }



}
