
package telas;

import Dao.Daofases;
import model.fase;
import Dao.DataSource;
import java.util.ArrayList;
import javax.swing.JOptionPane;

import Dao.Daofases;
import Dao.DataSource;
import javax.swing.JOptionPane;
import model.fase;


public class jifAlteracaoFases extends javax.swing.JInternalFrame {
    private int idRegistro = -1;
    public jifAlteracaoFases() {
        initComponents();
        btnAlterar.addActionListener(e -> btnAlterarActionPerformed(e));
        btnApagar.addActionListener(e -> btnApagarActionPerformed(e));
        carregarRegistro();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lbl2 = new javax.swing.JLabel();
        txt1 = new javax.swing.JTextField();
        btnVoltar = new javax.swing.JButton();
        btnApagar = new javax.swing.JButton();
        lbl3 = new javax.swing.JLabel();
        btnAlterar = new javax.swing.JButton();

        setBackground(new java.awt.Color(204, 204, 255));
        setClosable(true);

        pnl1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Alteração de Fases");

        lbl2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        txt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt1ActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar ao Menu");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnApagar.setText("Apagar");

        lbl3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl3.setText("Descrição da Fase");

        btnAlterar.setText("Alterar");

        javax.swing.GroupLayout pnl1Layout = new javax.swing.GroupLayout(pnl1);
        pnl1.setLayout(pnl1Layout);
        pnl1Layout.setHorizontalGroup(
            pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(lbl2)
                .addGap(18, 18, 18)
                .addComponent(btnVoltar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                .addContainerGap(141, Short.MAX_VALUE)
                .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                        .addComponent(lblTitulo)
                        .addGap(124, 124, 124))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                        .addComponent(txt1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                        .addComponent(btnApagar)
                        .addGap(224, 224, 224))))
            .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnl1Layout.createSequentialGroup()
                    .addGap(64, 64, 64)
                    .addComponent(lbl3)
                    .addContainerGap(405, Short.MAX_VALUE)))
            .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnl1Layout.createSequentialGroup()
                    .addGap(174, 174, 174)
                    .addComponent(btnAlterar)
                    .addContainerGap(377, Short.MAX_VALUE)))
        );
        pnl1Layout.setVerticalGroup(
            pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl1Layout.createSequentialGroup()
                .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl1Layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(lbl2))
                    .addGroup(pnl1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(lblTitulo)
                        .addGap(18, 18, 18)
                        .addComponent(btnVoltar)))
                .addGap(52, 52, 52)
                .addComponent(txt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(btnApagar)
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                    .addContainerGap(180, Short.MAX_VALUE)
                    .addComponent(lbl3)
                    .addGap(151, 151, 151)))
            .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                    .addContainerGap(259, Short.MAX_VALUE)
                    .addComponent(btnAlterar)
                    .addGap(74, 74, 74)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(pnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(98, 98, 98))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(pnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt1ActionPerformed(java.awt.event.ActionEvent evt) {
    }                                    

    


    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    
    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        if (idRegistro <= 0) return;
        try {
            fase registro = new fase();
            registro.setIdFase(idRegistro);
            registro.setDsFase(txt1.getText().trim());
            new Daofases(new DataSource()).alterar(registro);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Confira o código informado.", "Dados inválidos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnApagarActionPerformed(java.awt.event.ActionEvent evt) {
        txt1.setText("");
    }

    private void carregarRegistro() {
        String codigo = JOptionPane.showInputDialog(this, "Código do registro:");
        if (codigo == null) { dispose(); return; }
        try {
            idRegistro = Integer.parseInt(codigo.trim());
            ArrayList<fase> lista = new Daofases(new DataSource()).consulta();
            for (fase registro : lista) {
                if (registro.getIdFase() == idRegistro) {
                    txt1.setText(registro.getDsFase());
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Registro não encontrado.", "Consulta", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Informe um código numérico válido.", "Código inválido", JOptionPane.ERROR_MESSAGE);
            dispose();
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnApagar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lbl2;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel pnl1;
    private javax.swing.JTextField txt1;
    // End of variables declaration//GEN-END:variables
}
