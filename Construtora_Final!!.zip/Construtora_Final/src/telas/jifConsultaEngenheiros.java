
package telas;

import Dao.Daoengenheiros;
import model.engenheiro;
import Dao.DataSource;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class jifConsultaEngenheiros extends javax.swing.JInternalFrame {
    public jifConsultaEngenheiros() {
        initComponents();
        btnAtualizar.addActionListener(e -> atualizarConsulta(true));
        atualizarConsulta(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lbl2 = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        btnIncluir = new javax.swing.JButton();
        pnl2 = new javax.swing.JPanel();
        lbl5 = new javax.swing.JLabel();
        lbl6 = new javax.swing.JLabel();
        pnl3 = new javax.swing.JPanel();
        lbl3 = new javax.swing.JLabel();
        lbl4 = new javax.swing.JLabel();
        lbl7 = new javax.swing.JLabel();
        lbl9 = new javax.swing.JLabel();
        lbl8 = new javax.swing.JLabel();
        lbl10 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 204, 255));
        setClosable(true);

        pnl1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Consulta de Engenheiros");

        lbl2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        btnVoltar.setText("Voltar ao Menu");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnIncluir.setText("Incluir");
        btnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIncluirActionPerformed(evt);
            }
        });

        pnl2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lbl5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl5.setText("1");

        lbl6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl6.setText("Engenheiro");

        pnl3.setBackground(new java.awt.Color(153, 255, 153));

        lbl3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl3.setText("Código");

        lbl4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl4.setText("CREA");

        lbl7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl7.setText("Nome");

        lbl9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl9.setText("Data de Admissão");

        javax.swing.GroupLayout pnl3Layout = new javax.swing.GroupLayout(pnl3);
        pnl3.setLayout(pnl3Layout);
        pnl3Layout.setHorizontalGroup(
            pnl3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lbl3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(lbl7, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(lbl4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl9, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(121, 121, 121))
        );
        pnl3Layout.setVerticalGroup(
            pnl3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl3Layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addGroup(pnl3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl3)
                    .addComponent(lbl4)
                    .addComponent(lbl7)
                    .addComponent(lbl9)))
        );

        lbl8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl8.setText("10/11/2026");

        lbl10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbl10.setText("123456");

        javax.swing.GroupLayout pnl2Layout = new javax.swing.GroupLayout(pnl2);
        pnl2.setLayout(pnl2Layout);
        pnl2Layout.setHorizontalGroup(
            pnl2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lbl5)
                .addGap(85, 85, 85)
                .addComponent(lbl6)
                .addGap(80, 80, 80)
                .addComponent(lbl10)
                .addGap(42, 42, 42)
                .addComponent(lbl8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(pnl3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnl2Layout.setVerticalGroup(
            pnl2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl2Layout.createSequentialGroup()
                .addComponent(pnl3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnl2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl5)
                    .addGroup(pnl2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbl6)
                        .addComponent(lbl10)
                        .addComponent(lbl8)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnl1Layout = new javax.swing.GroupLayout(pnl1);
        pnl1.setLayout(pnl1Layout);
        pnl1Layout.setHorizontalGroup(
            pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl1Layout.createSequentialGroup()
                .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl1Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(lbl2))
                    .addGroup(pnl1Layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(pnl2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(82, Short.MAX_VALUE))
            .addGroup(pnl1Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(btnVoltar)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                        .addComponent(btnIncluir)
                        .addGap(138, 138, 138)
                        .addComponent(btnAtualizar)
                        .addGap(333, 333, 333))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl1Layout.createSequentialGroup()
                        .addComponent(lblTitulo)
                        .addGap(156, 156, 156))))
        );
        pnl1Layout.setVerticalGroup(
            pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(lblTitulo)
                .addGap(18, 18, 18)
                .addComponent(btnVoltar)
                .addGap(29, 29, 29)
                .addComponent(lbl2)
                .addGap(18, 18, 18)
                .addComponent(pnl2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(pnl1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAtualizar)
                    .addComponent(btnIncluir))
                .addGap(39, 39, 39))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(104, Short.MAX_VALUE)
                .addComponent(pnl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    


    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIncluirActionPerformed
        jifInclusaoEngenheiros janela = new jifInclusaoEngenheiros();
        getDesktopPane().add(janela);
        janela.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnIncluirActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAtualizarActionPerformed

    
    private void atualizarConsulta(boolean mostrarLista) {
        ArrayList<engenheiro> lista = new Daoengenheiros(new DataSource()).consulta();
        StringBuilder texto = new StringBuilder();
        if (!lista.isEmpty()) {
            lbl5.setText(String.valueOf(lista.get(0).getIdEngenheiro()));
            lbl6.setText(lista.get(0).getDsNome());
            lbl8.setText(lista.get(0).getDtAdmissao() == null ? "-" : lista.get(0).getDtAdmissao().toString());
            lbl10.setText(lista.get(0).getNrCREA());
        } else {
            lbl5.setText("-");
            lbl6.setText("Nenhum engenheiro encontrado");
            lbl8.setText("-");
            lbl10.setText("-");
        }
        for (engenheiro item : lista) texto.append(item.getIdEngenheiro()).append(" - ").append(item.getDsNome()).append(" - CREA ").append(item.getNrCREA()).append(" - ").append(item.getDtAdmissao()).append(System.lineSeparator());
        if (mostrarLista) {
            if (lista.isEmpty()) texto.append("Nenhum registro encontrado.");
            JOptionPane.showMessageDialog(this, texto.toString(), "Engenheiros", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnIncluir;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lbl10;
    private javax.swing.JLabel lbl2;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lbl4;
    private javax.swing.JLabel lbl5;
    private javax.swing.JLabel lbl6;
    private javax.swing.JLabel lbl7;
    private javax.swing.JLabel lbl8;
    private javax.swing.JLabel lbl9;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnl3;
    // End of variables declaration//GEN-END:variables
}
